import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.junit.Test;


public class TestHelpers {

	@Test
	public void test() {
		
		for (int i = 0; i < 10000; i++) {
			Integer val = KonkordansKonstruktion.convertToInt(KonkordansKonstruktion.convertToByte(i));
			if(val != i){
				fail("error!");
			}
		}
	}
	
	@Test
	public void charsetTest() throws Throwable{
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("tmp"));
		byte[] b = new byte[]{0,0,4,-93};
		for (int i = 0; i < b.length; i++) {
			bufferedWriter.write(b[i]);
		}
//		bufferedWriter.write(new String(b, "ISO-8859-1"));
		bufferedWriter.close();
		
		FileWriter writer = new FileWriter("tmp");
		
		RandomAccessFile rnd = new RandomAccessFile("tmp", "r");
		rnd.read(b);
		for (int i = 0; i < b.length; i++) {
			System.out.println(i + ":" + b[i]);
		}
		rnd.close();
		
		System.out.println("oe" + new String(b));
		
	}
	

}

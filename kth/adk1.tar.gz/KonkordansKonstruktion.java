import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeSet;

/**
 * Create the idices needed to
 * 
 * @author jensst
 * @param <E>
 * 
 */
public class KonkordansKonstruktion {

	private static final String CHARSET = "ISO-8859-1";
	private boolean debug = true;
	private int numlines = 2;
	private static final String IDX_DELIMITER = "<<<";
	private static final String NAME_DELIMITER = "~>~";
	private static final String INDICES_FILE = "/var/tmp/jensst_konk_idx";
	private static final String NAME_TO_INDICES_MAP_FILE = "/var/tmp/jensst_konk_intern";
	private static final String DATA_FILE = "/info/adk12/labb1/korpus";
	private static final int NEWLINE_CHARCOUNT = 1;

	// en trie på 2-3 tecken, som i sin tur pekar ut en position i cache-filen

	/**
	 * Representation of a word
	 */

	public static void main(String[] args) throws Exception {
		new KonkordansKonstruktion();
	}

	class T implements Serializable {
		private static final long serialVersionUID = 4656161156350651328L;
		int[][] t;
	}

	class TrieNode {

		char c;
		boolean isword;
		int line;

		Map<Integer, TrieNode> children = new HashMap<Integer, TrieNode>();

		public TrieNode() {

		}

		public TrieNode(char c, boolean isword) {
			super();
			this.c = c;
			this.isword = isword;
		}

		void build(String w, int pos) {
			if (pos < w.length()) {
				TrieNode node = children.get(w.charAt(pos) + 0);
				if (node == null) {
					node = new TrieNode(w.charAt(pos), pos == w.length() - 1);
					children.put(0 + w.charAt(pos), node);
				}
				if (pos == w.length() - 1) {
					node.isword = true;
				}
				node.build(w, pos + 1);
			}
		}

		boolean contains(String w, int pos) {
			TrieNode node = children.get(w.charAt(pos) + 0);
			if (node != null) {
				if (pos == w.length() - 1) {
					return node.isword;
				}
				return node.contains(w, pos + 1);
			}
			return false;
		}

		@Override
		public String toString() {
			return "Node [c=" + c + ", isword=" + isword + ", children=" + children + "]";
		}
	}


	public KonkordansKonstruktion() throws Exception {
		long t0 = System.currentTimeMillis();

		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File(DATA_FILE)), CHARSET));

		// Read the words from file
		Map<String, Word> allWords = new HashMap<String, Word>();
		retrieveWords(reader, allWords);

		// Sort the words
		TreeSet<String> set = new TreeSet<String>();
		set.addAll(allWords.keySet());

		// create a sorted sequence of the words indices and store them in the indices file.
		// each word must know how many positions are saved to be able to know their own position
		writeWordIndices(allWords, set);

		// Each line represents a lookup for a certain name, on the form "name nrOccurrance firstposinfile"
		writeNameToIndexLookupFile(allWords, set);

		String searchword = "en";

		List<Integer> indices = retrieveIndices(searchword, 0, 1000);
		System.out.println(indices.size() + " hits:");
		for (int i = 0; i < indices.size(); i++) {
			Integer idx = indices.get(i);

			String str = getDataFromIdx(idx);
			System.out.println(str);
		}
		
		System.out.println("Time used: " + (System.currentTimeMillis() - t0 + 500) / 1000 + " seconds.");
	}

	private String getDataFromIdx(Integer idx) throws Exception {
		RandomAccessFile rndFile = new RandomAccessFile(DATA_FILE, "r");
		rndFile.seek(idx - 20);
		byte[] buf = new byte[50];
		rndFile.read(buf);
		System.out.println("seeking to idx " + idx );
		String ret = new String(buf, CHARSET).replace("\n", " ");
		return ret;
	}

	private List<Integer> retrieveIndices(String searchword, int lo, int hi) throws Exception {

		RandomAccessFile rnd = new RandomAccessFile(INDICES_FILE, "r");

		searchword = searchword.toLowerCase();
		byte[] buf = new byte[8 * 1024];
		while (hi - lo < 1000) {
			int mid = (hi + lo) / 2;
			rnd.seek(mid);

			rnd.read(buf);
			String string = new String(buf);

			int indexOf = string.indexOf(NAME_DELIMITER);
			if (indexOf != -1) {
				String name = getName(string);

				if (searchword.compareTo(name) < 0) {
					lo = mid;
				} else {
					hi = mid;
				}
			}
		}

		rnd.seek(lo);
		rnd.read(buf);
		
		//use bytes directly!
		String str = new String(buf);
		StringTokenizer tokenizer = new StringTokenizer(str, NAME_DELIMITER);

		while (tokenizer.hasMoreTokens()) {
			String token = tokenizer.nextToken();
			String name = getName(token);

			if (name.equals(searchword)) {
				return getOccurrances(token);
			}
		}

		return new ArrayList<Integer>();
	}

	private String getName(String string) {
		return string.split(IDX_DELIMITER)[0];
	}

	private List<Integer> getOccurrances(String string) throws Exception {
		String[] split = string.split(IDX_DELIMITER);
		String s = split.length >= 2 ? split[1] : "";
		List<Integer> ret = new ArrayList<Integer>();

		byte[] b = new byte[4];
		for (int i = 0; i < s.length() - 3; i += 4) {
			String substring = s.substring(i, i + 4);
			for (int j = 0; j < 4; j++) {
				b[j] = (byte) substring.charAt(j);
				
				System.out.println(substring.charAt(j) + 0);
				
			}
			String string2 = new String(b, CHARSET);
			System.out.println(string2);
			ret.add(convertToInt(b));
		}

		return ret;
	}

	private void writeNameToIndexLookupFile(Map<String, Word> allWords, TreeSet<String> set) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(NAME_TO_INDICES_MAP_FILE));

		// write all our words to file
		for (String key : set) {
			Word word = allWords.get(key);
			writer.write(word.fileString());
		}
		writer.close();
	}

	// Writes all the words as bytes to easier look up the position
	private void writeWordIndices(Map<String, Word> allWords, TreeSet<String> set) throws IOException {
		// BufferedWriter idxWriter = new BufferedWriter(new FileWriter(INDICES_FILE));

		BufferedWriter idxWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(INDICES_FILE),  CHARSET));

		for (String string : set) {
			Word nextWord = allWords.get(string);

			idxWriter.write(NAME_DELIMITER + nextWord.getName() + IDX_DELIMITER);
			for (Integer position : nextWord.occurrances) {
				byte[] asBytes = convertToByte(position);
				if(nextWord.getName().equals("en")){
					System.out.println(nextWord.getName() + " gets position " + convertToInt(asBytes));
				}
				for (int i = 0; i < asBytes.length; i++) {
					idxWriter.write(asBytes[i]);
				}
			}
		}

		idxWriter.write(NAME_DELIMITER);
		idxWriter.close();
	}

	private int retrieveWords(BufferedReader reader, Map<String, Word> allWords) throws IOException {
		int i = 0, pos = 0;
		List<Integer> delimiterCharacters = Arrays.asList(new Integer[] { '.', '\n', ' ' });

		// Process the file and store all words in the allWordsMap
		while (i < numlines || numlines  == -1) {
			i++;
			String line = reader.readLine();
			if (line == null)
				break;
			line = line.toLowerCase();
			
			if(debug ){
				System.out.println("Read a line:");
				System.out.println(line);
			}
			
			StringBuilder curStr = new StringBuilder();

			for (int j = 0; j < line.length(); j++) {
				int c = line.charAt(j);

				if (delimiterCharacters.contains(c)) {
					
					addWord(curStr, pos, allWords);
					pos += curStr.length() + 1;
					curStr = new StringBuilder();
				} else {
					curStr.append((char) c);
				}
			}

			pos += NEWLINE_CHARCOUNT;
		}
		return pos;
	}

	static Integer convertToInt(byte[] asBytes) {
		return new BigInteger(asBytes).intValue();
	}

	static byte[] convertToByte(int maxValue) {
		byte[] arr = BigInteger.valueOf(maxValue).toByteArray();
		int shift = 4 - arr.length;
		byte[] ret = new byte[4];
		for (int i = 0; i < arr.length; i++) {
			ret[i + shift] = arr[i];
		}
		return ret;
	}

	private void addWord(StringBuilder curStr, int pos, Map<String, Word> allWords) {
		String entireWord = curStr.toString();
		if(entireWord.equals("en")){
			System.out.println("The word en has position: " + pos);
		}
		if (allWords.containsKey(entireWord)) {
			Word word = allWords.get(entireWord);
			word.wordcnt++;
			word.occurrances.add(pos);
		} else {
			allWords.put(entireWord, new Word("", entireWord, pos));
		}
	}
}
